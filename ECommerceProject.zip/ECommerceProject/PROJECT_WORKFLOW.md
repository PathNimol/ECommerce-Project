# Tech Com Service and Repair - E-Commerce Project Workflow

## Project Overview
This is a professional e-commerce platform for selling computers and computer-related products, built with Django REST Framework and Bootstrap.

**Primary Color:** `#172488` (Deep Blue)
**Business:** Tech Com Service and Repair - Computer Store

---

## System Architecture

### Technology Stack
- **Backend:** Django 6.0 + Django REST Framework
- **Frontend:** Bootstrap 5.3 + Vanilla JavaScript
- **Database:** SQLite (development)
- **Rich Text Editor:** CKEditor with Uploader
- **Image Processing:** Pillow

---

## Project Structure

```
ECommerceProject/
├── ECommerceApp/              # Main application
│   ├── models.py             # Database models
│   ├── views.py              # API viewsets and template views
│   ├── serializers.py        # DRF serializers
│   ├── urls.py               # URL routing
│   ├── admin.py              # Django admin configuration
│   ├── management/
│   │   └── commands/
│   │       └── load_sample_data.py  # Sample data loader
│   └── templates/
│       └── ECommerceApp/
│           ├── ECommerceFrontEnd.html    # Customer-facing store
│           ├── ECommerceBackEnd.html     # Admin dashboard
│           └── ListProductWithAddToCartCheckoutOrder.html
├── ECommerceProject/         # Project settings
│   ├── settings.py          # Django settings
│   ├── urls.py              # Root URL configuration
│   └── wsgi.py              # WSGI configuration
└── media/                    # User-uploaded files
    └── images/              # Product images, banners, etc.
```

---

## Database Models & Roles

### 1. **Category Model**
**Purpose:** Organize products into categories
- `categoryName`: Name of the category (e.g., "Laptops", "Desktops")
- `categoryImage`: Category thumbnail image

**Role:** Product organization and navigation

---

### 2. **Product Model**
**Purpose:** Store product information
- `productName`: Product name
- `categoryID`: Foreign key to Category
- `price`: Product price
- `productDescript`: Rich text description
- `weight`: Product weight
- `availability`: Stock status
- `shipping`: Shipping information
- `productImage`: Product image
- `productDate`: Creation timestamp

**Role:** Core product data storage

---

### 3. **ProductDetail Model**
**Purpose:** Detailed product specifications
- `productID`: Foreign key to Product
- `productDetailName`: Detail section name
- `Description`: Full product description
- `Information`: Technical specifications
- `Reviews`: Customer reviews

**Role:** Extended product information display

---

### 4. **ProductDetailImage Model**
**Purpose:** Additional product images
- `productID`: Foreign key to Product
- `productDetailImageName`: Image name
- `productDetailImage`: Image file

**Role:** Product gallery management

---

### 5. **Order Model**
**Purpose:** Customer orders
- `customerName`: Customer name
- `customerPhone`: Contact phone
- `orderDate`: Order timestamp
- `totalAmount`: Total order value
- `QRCodeInvoice`: Payment QR code image

**Role:** Order management and tracking

---

### 6. **OrderItem Model**
**Purpose:** Individual items in an order
- `order`: Foreign key to Order
- `productName`: Product name (snapshot)
- `price`: Price at time of order
- `qty`: Quantity ordered

**Role:** Order line items tracking

---

### 7. **TblBanner Model**
**Purpose:** Homepage banners/promotions
- `BannerName`: Banner title
- `BannerImage`: Banner image
- `BannerDate`: Creation date

**Role:** Marketing and promotions display

---

### 8. **Image Model**
**Purpose:** Dynamic image management
- `ImageName`: Image name
- `ImageURL`: Image file
- `ImageLink`: Optional link URL
- `ImageTypeID`: Foreign key to ImageType
- `Active`: Status flag
- `ImageDate`: Creation date

**Role:** Flexible image content management

---

### 9. **ImageType Model**
**Purpose:** Categorize images by usage
- `ImageTypeName`: Type name (Logo, Banner, Sidebar, etc.)

**Image Types:**
- Type 1: Banner
- Type 2: Slider
- Type 3: Sidebar Left
- Type 4: Sidebar Right
- Type 5: Footer
- Type 6: Logo

**Role:** Image organization and placement

---

### 10. **Menu Model**
**Purpose:** Navigation menu items
- `MenuNameKH`: Khmer name
- `MenuNameEN`: English name
- `OrderBy`: Display order
- `CreatedDate`: Creation date

**Role:** Site navigation structure

---

### 11. **MenuDetail Model**
**Purpose:** Menu item descriptions
- `MenuID`: Foreign key to Menu
- `Description`: Rich text content
- `MenuDetailDate`: Creation date

**Role:** Menu content management

---

### 12. **QRCode Model**
**Purpose:** Payment QR codes
- `qrName`: QR code name (e.g., "ABA Bank")
- `qrImage`: QR code image

**Role:** Payment processing integration

---

## API Endpoints

### REST API (Django REST Framework)

All endpoints are available at: `http://127.0.0.1:8000/`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/banners/` | GET, POST | Banner management |
| `/imagetypes/` | GET, POST | Image type management |
| `/images/` | GET, POST | Image management |
| `/menus/` | GET, POST | Menu management |
| `/menudetails/` | GET, POST | Menu detail management |
| `/categories/` | GET, POST | Category management |
| `/products/` | GET, POST | Product listing |
| `/products/?categoryID=X` | GET | Filter by category |
| `/productdetails/` | GET, POST | Product detail management |
| `/productdetails/?productID=X` | GET | Filter by product |
| `/productdetailimages/` | GET, POST | Product image gallery |
| `/qrcodes/` | GET, POST | QR code management |
| `/orders/` | GET, POST | Order management |

---

## Frontend Pages

### 1. **Customer Storefront**
**URL:** `http://127.0.0.1:8000/ECommerceFrontEnd/`

**Features:**
- Product browsing by category
- Product search and filtering
- Shopping cart
- Order placement
- Invoice generation
- Order history
- Banner carousel
- Product slider
- Menu navigation

**User Role:** Customer

---

### 2. **Admin Dashboard**
**URL:** `http://127.0.0.1:8000/ECommerceBackEnd/`

**Features:**
- CRUD operations for all models
- Statistics dashboard
- Order management
- Product management
- Banner management
- Image management
- Menu management

**User Role:** Administrator

---

### 3. **Product Listing with Cart**
**URL:** `http://127.0.0.1:8000/ListProductWithAddToCartCheckoutOrder/`

**Features:**
- Simplified product listing
- Shopping cart
- Checkout process

**User Role:** Customer

---

## Workflow by User Role

### 👤 **Customer Workflow**

1. **Browse Products**
   - Visit `/ECommerceFrontEnd/`
   - View banners and promotions
   - Browse products by category
   - Use search and price filters

2. **View Product Details**
   - Click "Details" on any product
   - View full specifications
   - Read reviews and information

3. **Add to Cart**
   - Click "Add to Cart" button
   - Products added to shopping cart
   - Cart shows quantity and total

4. **Checkout**
   - Fill customer information (name, phone)
   - Select or upload payment QR code
   - Click "Place Order"
   - Receive invoice confirmation

5. **View Order History**
   - View past orders in sidebar
   - Click "View Invoice" for details
   - Print invoices

---

### 👨‍💼 **Administrator Workflow**

1. **Access Admin Dashboard**
   - Visit `/ECommerceBackEnd/`
   - View statistics and overview

2. **Manage Products**
   - Create/Edit/Delete categories
   - Add products with images
   - Set prices and availability
   - Add product details and specifications

3. **Manage Content**
   - Upload banners for promotions
   - Manage slider images
   - Update sidebar images
   - Manage footer content
   - Upload logo

4. **Manage Orders**
   - View all orders
   - Track order status
   - View customer information
   - Generate reports

5. **Manage Menus**
   - Create navigation menus
   - Add menu descriptions
   - Organize menu order

6. **Manage QR Codes**
   - Add payment QR codes
   - Update bank information

---

### 🔧 **Developer Workflow**

1. **Setup**
   ```bash
   # Activate virtual environment
   cd ECommerceProject
   python manage.py migrate
   python manage.py createsuperuser
   ```

2. **Load Sample Data**
   ```bash
   python manage.py load_sample_data
   ```

3. **Run Development Server**
   ```bash
   python manage.py runserver
   ```

4. **Access Admin Panel**
   - Visit `http://127.0.0.1:8000/admin/`
   - Login with superuser credentials

5. **API Testing**
   - Visit `http://127.0.0.1:8000/` for API root
   - Use browser or Postman for API testing

---

## Data Flow

### Product Display Flow
```
Category → Product → ProductDetail → ProductDetailImage
     ↓
Frontend Display
```

### Order Processing Flow
```
Customer adds products to cart
     ↓
Fill customer information
     ↓
Select/Upload QR code
     ↓
Place Order → Order created
     ↓
OrderItem records created
     ↓
Invoice generated
     ↓
Order history updated
```

### Image Management Flow
```
Upload image → ImageType assigned
     ↓
Image displayed based on ImageTypeID:
  - Type 1: Banners
  - Type 2: Slider
  - Type 3: Sidebar Left
  - Type 4: Sidebar Right
  - Type 5: Footer
  - Type 6: Logo
```

---

## Key Features

### ✅ **Implemented Features**
- Product catalog with categories
- Shopping cart functionality
- Order management system
- Invoice generation
- Payment QR code integration
- Banner and slider management
- Responsive design
- API-first architecture
- Admin dashboard
- Order history tracking
- Product search and filtering
- Rich text product descriptions

### 🎨 **Design Features**
- Professional color scheme (#172488)
- Modern UI with Bootstrap 5
- Font Awesome icons
- Smooth animations and transitions
- Responsive mobile design
- Professional product cards
- Clean admin interface

---

## File Upload Locations

All uploaded files are stored in `media/images/`:

- `media/images/Banners/` - Banner images
- `media/images/Categories/` - Category images
- `media/images/Products/` - Product images
- `media/images/Dynamic/` - Dynamic images (sliders, sidebars, etc.)
- `media/images/qrcodes/` - QR code images
- `media/images/QRCodeInvoice/` - Order payment QR codes

---

## Configuration

### Settings (settings.py)
- `MEDIA_URL = '/media/'`
- `MEDIA_ROOT = BASE_DIR / 'media'`
- `STATIC_URL = 'static/'`
- CKEditor configured for rich text editing

### Installed Apps
- `rest_framework` - API framework
- `ECommerceApp` - Main application
- `ckeditor` - Rich text editor
- `ckeditor_uploader` - Image upload for editor

---

## Security Notes

⚠️ **For Production:**
- Change `SECRET_KEY`
- Set `DEBUG = False`
- Configure `ALLOWED_HOSTS`
- Use PostgreSQL instead of SQLite
- Implement authentication/authorization
- Add CSRF protection
- Use HTTPS
- Implement rate limiting
- Add input validation

---

## Support & Contact

**Tech Com Service and Repair**
- Website: Your domain
- Phone: (855) 123-4567
- Email: info@techcom.com

---

## Version History

- **v1.0** - Initial release with full e-commerce functionality
- Professional styling with #172488 color scheme
- Computer product focus
- Complete admin dashboard
- API-first architecture

---

*Last Updated: December 2025*

