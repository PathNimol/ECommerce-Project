# 🛠️ How to Manage Products & Everything

## 📍 Where to Manage Everything

### **Admin Dashboard (Main Management Panel)**
**URL:** `http://127.0.0.1:8000/ECommerceBackEnd/`

This is your main admin panel where you can:
- ✅ **Manage Products** - Add, Edit, Delete products
- ✅ **Manage Categories** - Organize products by category
- ✅ **Manage Banners** - Upload promotional banners
- ✅ **Manage Images** - Upload logos, slider images, sidebar images
- ✅ **Manage QR Codes** - Add payment QR codes
- ✅ **Manage Orders** - View and manage customer orders
- ✅ **View Statistics** - See sales, orders, and product counts

### **Django Admin Panel (Advanced)**
**URL:** `http://127.0.0.1:8000/admin/`

For advanced database management:
- Direct database access
- User management
- Model administration

---

## 🎯 Quick Start Guide

### 1. **Access Admin Dashboard**
1. Open your browser
2. Go to: `http://127.0.0.1:8000/ECommerceBackEnd/`
3. You'll see the admin dashboard with all management options

### 2. **Manage Products**
1. Click on **"Products"** section in the sidebar
2. Click **"Add New Product"** button
3. Fill in:
   - Product Name
   - Category
   - Price
   - Weight
   - Availability
   - Shipping Info
   - **Upload Product Image** (important!)
   - Description
4. Click **"Save"**

### 3. **Manage Banners (Featured Promotions)**
1. Click on **"Banners"** section
2. Click **"Add New Banner"**
3. Upload banner image
4. Enter banner name
5. Save

### 4. **Manage Slider Images (Latest Products)**
1. Click on **"Images"** section
2. Click **"Add New Image"**
3. Select **ImageTypeID = 2** (for Slider/Latest Products)
4. Upload image
5. Enter image name
6. Save

### 5. **Upload Logo**
1. Go to **"Images"** section
2. Click **"Add New Image"**
3. Select **ImageTypeID = 6** (for Logo)
4. Upload your logo image
5. Save

### 6. **Add QR Codes**
1. Go to **"QR Codes"** section
2. Click **"Add New QR Code"**
3. Enter QR code name (e.g., "ABA Bank")
4. Upload QR code image
5. Save

---

## 📋 Image Type IDs Reference

| ImageTypeID | Purpose | Where It Appears |
|------------|---------|------------------|
| 1 | Banner | Featured Promotions carousel |
| 2 | Slider | Latest Products carousel |
| 3 | Sidebar Left | Left sidebar images |
| 4 | Sidebar Right | Right sidebar images |
| 5 | Footer | Footer images |
| 6 | Logo | Header logo |

---

## 🔧 API Endpoints (For Developers)

You can also manage data via API:

- **Products:** `GET/POST/PUT/DELETE /products/`
- **Categories:** `GET/POST/PUT/DELETE /categories/`
- **Banners:** `GET/POST/PUT/DELETE /banners/`
- **Images:** `GET/POST/PUT/DELETE /images/`
- **QR Codes:** `GET/POST/PUT/DELETE /qrcodes/`
- **Orders:** `GET/POST /orders/`

---

## 💡 Tips

1. **Product Images:** Always upload product images for better display
2. **Banner Size:** Recommended 1200x400px for banners
3. **Logo:** Use PNG with transparent background for best results
4. **QR Codes:** Keep QR code images clear and readable
5. **Categories:** Organize products into categories for better navigation

---

## 🚀 Quick Links

- **Frontend Store:** `http://127.0.0.1:8000/ECommerceFrontEnd/`
- **Admin Dashboard:** `http://127.0.0.1:8000/ECommerceBackEnd/`
- **Django Admin:** `http://127.0.0.1:8000/admin/`

---

## ❓ Need Help?

Check these files for more details:
- `IMAGE_UPLOAD_GUIDE.md` - Detailed image upload instructions
- `PROJECT_WORKFLOW.md` - Complete project workflow
- `README.md` - Project overview

