# How to Edit the Logo

## Overview

The logo is managed through the **Backend Admin Dashboard** using the "Manage Images" section.

## Steps to Edit/Change the Logo

### Method 1: Via Admin Dashboard (Recommended)

1. **Access the Admin Dashboard**

   - Go to: `http://127.0.0.1:8000/ECommerceBackEnd/` (or your production URL)
   - Or click the "Admin Panel" button in the frontend header

2. **Navigate to "Manage Images" Section**

   - In the sidebar, click on **"Content"** → **"Manage Images"**
   - This will show you the Images CRUD section

3. **Find or Create Logo Image**

   - Look for an existing image with **ImageTypeID = 6** (Logo type)
   - If no logo exists, you'll need to create one

4. **Edit Existing Logo**

   - Find the logo image in the table (it should have ImageTypeID = 6)
   - Click the **"Edit"** button for that image
   - The form will populate with the current logo data
   - **Upload a new image file** using the "Image File" field
   - Or update the "Image Link" if using an external URL
   - Click **"💾 Save Image"**

5. **Create New Logo (if none exists)**
   - Fill in the form:
     - **Image Name**: e.g., "Company Logo"
     - **Image Link**: (optional) External URL if not uploading a file
     - **Active Status**: "Y" (for Yes)
     - **Image Type**: Select **"6"** (Logo) from the dropdown
     - **Image File**: Upload your logo image file
   - Click **"💾 Save Image"**

### Method 2: Via Django Admin Panel

1. **Access Django Admin**

   - Go to: `http://127.0.0.1:8000/admin/`
   - Login with your superuser credentials

2. **Navigate to Images**

   - Click on **"Images"** under "ECommerce App"
   - Find or create an image with **ImageTypeID = 6**

3. **Edit or Create Logo**
   - Click on an existing logo image to edit
   - Or click "Add Image" to create a new one
   - Ensure **ImageTypeID = 6** is selected
   - Upload your logo file
   - Save

### Method 3: Via API

You can also update the logo programmatically using the REST API:

```bash
# Update existing logo (replace {id} with actual image ID)
PUT /images/{id}/
{
  "ImageName": "Company Logo",
  "ImageTypeID": 6,
  "ImageURL": [upload new file],
  "Active": "Y"
}
```

## Logo Requirements

- **Image Type ID**: Must be **6** (Logo type)
- **Format**: PNG with transparent background recommended
- **Size**: Recommended 200x200px or larger (will be scaled automatically)
- **Active Status**: Must be "Y" (Yes) for the logo to display

## Where Logo Appears

The logo appears in:

- **Frontend Header**: Top left of the website
- **Backend Sidebar**: Top of the admin dashboard sidebar (if configured)

## Technical Details

- Logo images are stored in: `media/images/Dynamic/`
- The frontend automatically loads images with `ImageTypeID = 6`
- If no logo is found, a default badge with "TC" (Tech Com) initials is displayed
- Logo is loaded via the `/images/` API endpoint

## Troubleshooting

**Logo not showing?**

- Check that ImageTypeID = 6
- Verify Active Status = "Y"
- Ensure the image file uploaded successfully
- Check browser console for any loading errors
- Verify the image URL is accessible

**Want to remove the logo?**

- Set Active Status to "N" (No) for the logo image
- Or delete the logo image entry
